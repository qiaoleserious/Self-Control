//
//  ViewController.h
//  Self Control
//
//  Created by 乔乐 on 2018/3/28.
//  Copyright © 2018年 乔乐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

